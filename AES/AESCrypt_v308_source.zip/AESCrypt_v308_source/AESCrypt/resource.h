//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AESCrypt.rc
//
#define IDS_PROJNAME                    100
#define IDR_AESCRYPT                    101
#define IDR_AESCRYPTSHELLEXT            102
#define IDD_PASSWDDIALOG                103
#define IDD_PROGRESSDIALOG              104
#define IDB_CTXBITMAP                   201
#define IDC_PASSWD                      202
#define IDC_PASSWDCONFIRM               203
#define IDI_AESCRYPT                    204
#define IDC_ENTERPASSWD                 205
#define IDC_ENTERPASSWDCONFIRM          206
#define IDC_PROGRESSBAR                 207
#define IDC_ENCRYPTINGMSG               208
#define IDC_FILENAME                    209

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         210
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
